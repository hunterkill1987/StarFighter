#include "StdAfx.h"
#include "Game.h"


Game::Game(void):
	g_engine(NULL),
	player(NULL)
{
}

int Game::GameInit(IEngine* engine)
{
	if(engine != NULL)
	{
		g_engine = engine; 
		player = new Player();
		actor = new Actor();
		player->Init();
		player->pEvent = g_engine->GetEvent();
	}
	else
	{
		return 0;
	}
	SpawnActor(player);

	return 1;
}

void Game::Update(float fTime)
{
	TActor::iterator it;
	for(it=ActorMap.begin(); it!=ActorMap.end(); ++it)
	{	
		IActor* actor = it->first;
		actor->Update(fTime);
	}
}

void Game::SpawnActor(IActor* actor)
{
	printf("%s  %s \n",actor->GetSurface(),actor->GetName());

	if(actor != NULL)
	{
		g_engine->AddDrawActor(actor);
		ActorMap.insert(std::pair<IActor*,int>(actor, 0));
	}else
	{
		return;
	}
}

Game::~Game(void)
{
}
