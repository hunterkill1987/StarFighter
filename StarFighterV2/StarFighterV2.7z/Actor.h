#include "IActor.h"
#include "IEvent.h"
#include "IInputPlayer.h"
#ifndef ACTOR_H
#define ACTOR_H

class Actor : public IActor
{	
private:

	int mHealth;
	int maxHealth;

	int mShield;
	int maxShield;

	char* name;
	char* surface;

	float m_acceleration;
	float time;

	Vector2 m_rotation;
	Vector2 m_velocity;
	Vector2 m_position;
	
public:
	IActor* pActor;
	IEvent* pEvent;

	bool aIsPlayer; 

	Actor(void);
	~Actor(void);

	virtual void Update(float fTime);
	
	virtual bool IsAlive();
	virtual bool IsPlayer();

	virtual int GetHealth();
	virtual int GetShield();

	virtual char* GetSurface();
	virtual char* GetName();

	virtual Vector2 GetRotation();

	virtual Vector2 GetVelocity();
	virtual Vector2 GetPosition();

	void Init();
	void Reset();

	void StartFire();
	void StopFire();
	void MoveActor();

	void SetRotation(Vector2 rot);
	void SetVelocity(Vector2 vel);
	void SetPosition(Vector2 pos);
	void SetAcceleration(float acc);
	void SetSurface (char* surfaceName);
	void SetName(char* Name);

};
#endif
