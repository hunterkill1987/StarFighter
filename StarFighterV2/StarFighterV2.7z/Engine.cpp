#include "StdAfx.h"
#include "Engine.h"
#include "Event.h"
#include <math.h>

Engine::Engine():
	path(NULL),
	display(NULL),
	mActor(NULL),
	mEngine(NULL),
	Angle(0.0)
{
	mEngine = this;
	aEvent  = new Event();
}

int Engine::Init()
{
	if(!al_init()) {
	   fprintf(stderr, "failed to initialize allegro!\n");
	   return 0;
	}

    display = al_create_display(800, 600);

    if(!display) {
       fprintf(stderr, "failed to create display!\n");
	   al_destroy_display(display);
       return 0;
    }

	al_init_image_addon();
	al_clear_to_color(al_map_rgb(0,0,0));

	if(InitPath()==0)
	{
		fprintf(stderr,"Falid to Init Asset Path !!! \n");
		return -1;
	}
	
	if(aEvent)
	{
		aEvent->Init();
		
	}
	return 1;
}

int Engine::InitPath()
{
	if(!path)
	{
		path = al_get_standard_path(ALLEGRO_RESOURCES_PATH);
		al_append_path_component(path, "Assets");
		al_change_directory(al_path_cstr(path, '/'));
		return 1;
	}
	else
	{
		return 0;
	} 
}

void Engine::AddDrawActor(IActor* actor)
{	
	ALLEGRO_BITMAP* tmpbitmap;

	TActorMap::iterator it;

	if(path)
	{
		tmpbitmap = al_load_bitmap(actor->GetSurface());
		if(tmpbitmap)
		{
			Vector2 vec2= actor->GetPosition();
			mapActor.insert(std::pair<IActor*,ALLEGRO_BITMAP*>(actor, tmpbitmap));
		}
		else
		{
			fprintf(stderr, "Faild to load image!\n");
		}
	}
	//al_destroy_bitmap(tmpbitmap);
}
void Engine::Draw()
{
	IActor* actor;
	ALLEGRO_BITMAP* drawActor;

	TActorMap::iterator it;
	for(it=mapActor.begin(); it!=mapActor.end(); ++it)
	{	
		if( path)
		{
			actor = it->first;
			drawActor = it->second;

			Vector2 pos = actor->GetPosition();
			if(actor != NULL)
			{
				al_convert_mask_to_alpha(drawActor,(al_map_rgb(255,0,255)));
				//al_draw_bitmap(drawActor, pos.GetX(), pos.GetY(), 0);

				float width = al_get_bitmap_width(drawActor);
				float height = al_get_bitmap_height(drawActor);

				//Angle = (float)acos(ort.dot(r)/(rot.length()*ort.length()));
				if(actor->IsPlayer())
				{
					if(aEvent->GetInput() & ( 5 << RIGHT))
					{
						Angle =  (float)atan2(-1.f * actor->GetRotation().GetX(), -1.f *actor->GetRotation().GetY());
					}
					if(aEvent->GetInput() & ( 4 << LEFT))
					{
						Angle =  (float)atan2(actor->GetRotation().GetX(),actor->GetRotation().GetY());
					}
				}
				else
				{
					Angle =  (float)atan2(actor->GetRotation().GetX(),actor->GetRotation().GetY());
				}
				//printf(" %f %f ",pos.GetX(),pos.GetY());
				al_draw_rotated_bitmap(drawActor,width/2,height/2,pos.GetX(),pos.GetY(),Angle,0);
			}
		}
	}
}

double Engine::GetRadians(Vector2 vect)
{
	double angle;
	Vector2 v=vect;



	return angle = atan2(v.GetX(),v.GetY());
}

void Engine::DeInit()
{
	al_destroy_path(path);
	al_destroy_display(display);
}

void Engine::UpdateEngine()
{
	al_clear_to_color(al_map_rgb(0,0,0));

	if( aEvent != NULL)
	{
		Draw();
		aEvent->UpdateInput();
	}
	
	al_flip_display();
}

float Engine::GetScreenHight()
{
	return al_get_display_height(display);
}

float Engine::GetScreenWidth()
{
	return  al_get_display_width(display);
}

float Engine::GetSafeRegionHeight()
{
	return 1.0f;
}

float Engine::GetSafeRegionWidth()
{
	return 1.0f;
}

IEngine* Engine::GetEgnine()
{
	return mEngine;
}

IEvent* Engine::GetEvent()
{
		return aEvent;
}

Engine::~Engine(void)
{
}
