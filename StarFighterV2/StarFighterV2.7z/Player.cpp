#include "StdAfx.h"
#include "Player.h"

Player::Player(void):
Angle(0.0),
acc(0.0)
{
}

void Player::Update(float deltaTime)
{
	Vector2 oldVel = this->GetVelocity();
	Vector2 rotation(0,0);

	Actor::Update(deltaTime);

	if(this->pEvent != NULL)
	{ 
		int input=this->pEvent->GetInput();
		if(input > 0)
		{	
			/*if(acc < 10.0)
				acc++;
				*/
			if(input & ( 4 << LEFT))
			{
				Angle += deltaTime * 3.14f;
				if(Angle > 3.14f) Angle -= 3.14 * 2.f;
				rotation = Vector2(sinf(Angle), cos(Angle));
				this->SetRotation(rotation);
			}

			if(input & ( 5 << RIGHT))
			{
				Angle -= deltaTime * 3.14f;
				if(Angle < -3.14f) Angle += 3.14 * 2.f;
				rotation = Vector2(-1.f*sinf(Angle),-1.f* cos(Angle));
				this->SetRotation(rotation);
			}

			if( input & ( 1 << UP))
			{
				if(acc < 5.0)
					this->SetAcceleration(acc++);
			}

			if( input & ( 2 << DOWN))
			{
				if( acc >= 0 )
					this->SetAcceleration(acc--);
			}

			if( input & ( 8 << FIRE))
			{
					fprintf(stderr,"do shit!!!!");
			}
		}
		/*else
		if( fabsf(this->GetVelocity().length()) > 0 && acc != 0 )
		{
			acc--;
			fprintf(stderr,"acc %f \n",acc);
		}*/
	}
}

void Player::Init()
{
	this->SetSurface("herok.bmp");
	this->SetName("Player");
	this->aIsPlayer = true;
	
	Vector2 vec(0,0) ;
	
	vec = vec + Vector2(300,300);
	this->SetPosition(vec);
}

Player::~Player(void)
{
}
