#include "IInputPlayer.h"
#pragma once


class InputPlayer: IInputPlayer
{
public:
	InputPlayer(void);
	~InputPlayer(void);

	virtual void SetInput(int dir);
	virtual void SetInputStat(int dir);
	virtual int GetInput();
	virtual int GetInputState();
	IInputPlayer* GetInputPlayer();
};

