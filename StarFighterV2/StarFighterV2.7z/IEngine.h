#include <allegro5\allegro.h>
#include <allegro5\allegro_image.h>
#include "IEvent.h"
#include "IActor.h"
#ifndef IENGINE_H
#define IENGINE_H

class IEngine
{
public:
	virtual int Init() = 0;
	virtual void Draw()= 0;
	virtual void AddDrawActor(IActor* aActor) = 0;
	
	virtual float GetScreenHight() = 0;
	virtual float GetScreenWidth() = 0;

	virtual float GetSafeRegionHeight() = 0;
	virtual float GetSafeRegionWidth() = 0;

	virtual IEngine* GetEgnine() =0;

	virtual IEvent* GetEvent() =0;
};
#endif