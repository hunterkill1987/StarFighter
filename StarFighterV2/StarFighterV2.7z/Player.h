#pragma once
#include "actor.h"
#include "IEvent.h"
#include "InputPlayer.h"

class Player :
	public Actor
{
private:
	float maxacc;
	float acc;
	float Angle;

public:
	
	void Update(float fTime);
	void Init();

	void MovePlayer();

	Player(void);
	~Player(void);
};

