#include "StdAfx.h"
#include "InputPlayer.h"


InputPlayer::InputPlayer(void)
{
}

void InputPlayer::SetInput(int dir)
{
}

void InputPlayer::SetInputStat(int dir)
{
}

int InputPlayer::GetInput()
{
	return 1;
}

int InputPlayer::GetInputState()
{
	return 1;
}

IInputPlayer* InputPlayer::GetInputPlayer()
{
	return this;
}

InputPlayer::~InputPlayer(void)
{
}
