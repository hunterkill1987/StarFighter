#include <allegro5\allegro.h>
#include <allegro5\allegro_image.h>
#include <map>
#include "IEngine.h"
#include "IActor.h"
#include "Event.h"

typedef std::map<IActor* , ALLEGRO_BITMAP*>		TActorMap;
typedef std::map<ALLEGRO_BITMAP*,int>			TDrawMap;

class Engine : public IEngine
{
private:
	ALLEGRO_PATH		*path;
	ALLEGRO_DISPLAY		*display;
	ALLEGRO_BITMAP*		*bitmap;

	Event				*aEvent;

	TActorMap	mapActor;
	TDrawMap	mapDraw;

	float		Angle;

	int InitPath();

public:

	IActor				*mActor;
	IEngine				*mEngine;

	Engine();
	~Engine();

	virtual int Init();
	
	virtual void DeInit();

	//re define to private
	virtual void Draw();

	virtual void UpdateEngine();

	virtual void AddDrawActor(IActor* aActor);

	virtual float GetScreenHight();
	virtual float GetScreenWidth();

	virtual float GetSafeRegionHeight();
	virtual float GetSafeRegionWidth();

	virtual IEngine* GetEgnine();

	virtual IEvent* GetEvent();

	bool Running() {return aEvent->done; };
	double GetRadians (Vector2 vect);
};

