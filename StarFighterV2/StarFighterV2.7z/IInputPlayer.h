#pragma once

class IInputPlayer
{
public:

};

