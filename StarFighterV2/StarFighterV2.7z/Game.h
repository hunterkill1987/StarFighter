#pragma once
#include "IEngine.h"
#include "IActor.h"
#include "Player.h"
#include "Actor.h"
#include <map>

typedef std::map<IActor*,int>			TActor;

class Game
{
private:
	
	IEngine* g_engine;
	Player* player;
	IActor* actor;

	TActor ActorMap;

public:
	Game(void);
	
	void Update(float fTime);
	int GameInit(IEngine* g_engine);
	void SpawnActor(IActor* actor);

	~Game(void);
};

