#include "StdAfx.h"
#include "Actor.h"

Actor::Actor(void):
	mHealth(0),
	maxHealth(0),
	mShield(0),
	maxShield(0),
	name(NULL),
	surface(NULL),
	aIsPlayer(false),
	time(0.0),
	m_velocity(0,0),
	m_acceleration(0.0),
	m_rotation(0,0),
	m_position(0,0)
{

}

void Actor::Init()
{
}

void Actor::Update(float fTime)
{
	time = fTime;
	MoveActor();
}

void Actor::MoveActor()
{
	Vector2 velocity = GetVelocity();
	Vector2 rotation = GetRotation();

	Vector2 pos = GetPosition();
	Vector2 newpos = GetPosition();

	velocity = velocity + rotation * m_acceleration * time;

	float speed = velocity.length();
	if(fabsf(speed) > 5.0)
	{
		velocity.normalize();
		velocity = velocity * 5.0;
	}
 
	newpos = newpos + velocity ;
	SetVelocity(velocity);
	SetPosition(newpos);
}
void Actor::Reset()
{
}

void Actor::StartFire()
{
}

void Actor::StopFire()
{
}

bool Actor::IsAlive()
{
	return true;
}

bool Actor::IsPlayer()
{
	return aIsPlayer;
}

int Actor::GetHealth()
{
	return mHealth;
}

int Actor::GetShield()
{
	return mShield;
}

char* Actor::GetSurface()
{
	return surface;
}

Vector2 Actor::GetVelocity()
{
	return m_velocity;
}

void Actor::SetVelocity(Vector2 vel)
{
	//printf("%f  %f \n",vel.GetX(),vel.GetY());
	m_velocity = vel;
}

Vector2 Actor::GetRotation()
{
	return m_rotation;
}

Vector2 Actor::GetPosition() 
{
	//printf("%f  %f \n",m_position.x,m_position.y);
	return m_position;
}

char* Actor::GetName()
{
	return name;
}

void Actor::SetRotation(Vector2 rot)
{
		m_rotation = rot;
}
void Actor::SetPosition(Vector2 pos)
{
		//printf("%f  %f \n",pos.x,pos.y);
		m_position = pos;
}

void Actor::SetSurface (char* surfaceName)
{
	surface  = surfaceName;
}

void Actor::SetName(char* Name)
{
	name = Name;
}

void Actor::SetAcceleration(float acc)
{
	if(acc >=0 )
	{
		m_acceleration = acc;
	}
	else
	{
		m_acceleration = 0.0f;
	}
}

Actor::~Actor(void)
{
}
